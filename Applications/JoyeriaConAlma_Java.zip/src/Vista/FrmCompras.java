/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Modelo.Cliente;
import Modelo.Compra;
import Modelo.Producto;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import javax.swing.AbstractCellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 *
 * @author aldri
 */
public class FrmCompras extends javax.swing.JFrame {

    /**
     * Creates new form FrmCompras
     */
    private Cliente cliente;
    public FrmCompras(Cliente cliente) {
        this.cliente = cliente; //instanciamos el objeto recibido
        initComponents();
        inicializaTablaCompras(); //iniciamos la tabla
    }
    
    public void inicializaTablaCompras() {
    // Creamos la tabla de las compras
    DefaultTableModel modelo = (DefaultTableModel) tbListaCompras.getModel();
    
    // Creamos una lista con las compras
    ArrayList<Compra> listaCompras = (ArrayList<Compra>) cliente.getCompras();
    
    if (listaCompras.isEmpty()) {
        JOptionPane.showMessageDialog(rootPane, "La lista de compras esta vacia.");
    } 
    
    for (int i = 0; i < listaCompras.size(); i++) {
        Vector<Object> fila = new Vector<Object>();
        
        Compra compra = listaCompras.get(i); //Instanciamos la compra
        
        List<Producto> listaProductos =  compra.getProductosComprados();
        
        // Datos basicos de cualquier producto
        int num = generarNumeroAleatorio();
        fila.add(num);
        
        fila.add(compra.obtenerNombreProducto());
        
        fila.add(compra.getPago_total());
      
        fila.add("VER O EDITAR PEDIDO");
        
      
        modelo.addRow(fila);
    }
    TableColumn column = tbListaCompras.getColumnModel().getColumn(3); // Columna de "Accion"
    ButtonRendererEditor buttonEditor = new ButtonRendererEditor(tbListaCompras, listaCompras);
    column.setCellRenderer(new ButtonRendererEditor(tbListaCompras, listaCompras));
    column.setCellEditor(new ButtonRendererEditor(tbListaCompras, listaCompras));
}
 
    

     public static int generarNumeroAleatorio() {
        Random random = new Random();
        return random.nextInt(1001); // Genera un número entre 0 y 1000 (incluido)
    }
     
    
    public class ButtonRendererEditor extends AbstractCellEditor implements TableCellRenderer, TableCellEditor {
    private final JButton button;
    private String label;
    private int row;
    private JTable table;
    private List<Compra> listaCompras;  
   
    
    public ButtonRendererEditor(JTable table, List<Compra> listaCompras) {
        this.table = table;
        this.button = new JButton();
        
        this.listaCompras = listaCompras; //Instanciamos la lista de compras de la tabla
        
        // Agregar un evento al botón
        button.addActionListener(e -> handleButtonClick());
    }

    private void handleButtonClick() {
        // Evento al hacer click
                
        row = table.getSelectedRow();
        
        Compra compra = listaCompras.get(row);
        
        
        JFrame FrmCompras = (JFrame) SwingUtilities.getWindowAncestor(table);
        if (FrmCompras != null) {
            FrmCompras.dispose(); // Cerramos el frame padre
        } 
        
        FrmDetallesPedido frameDetalles = new FrmDetallesPedido(compra, cliente);
        frameDetalles.setVisible(true);
        stopCellEditing(); 
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        button.setText(value != null ? value.toString() : "Ver/Editar");
        return button;
    }

    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        this.row = row;
        button.setText(value != null ? value.toString() : "Ver/Editar");
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        return null; 
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbListaCompras = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(204, 153, 0));

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Compras Realizadas");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(317, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(278, 278, 278))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel1)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        tbListaCompras.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "# Compra", "Articulos comprados", "Total", "Ver o /editar pedido"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbListaCompras);
        if (tbListaCompras.getColumnModel().getColumnCount() > 0) {
            tbListaCompras.getColumnModel().getColumn(0).setResizable(false);
            tbListaCompras.getColumnModel().getColumn(0).setPreferredWidth(20);
            tbListaCompras.getColumnModel().getColumn(1).setResizable(false);
            tbListaCompras.getColumnModel().getColumn(1).setPreferredWidth(350);
            tbListaCompras.getColumnModel().getColumn(2).setResizable(false);
            tbListaCompras.getColumnModel().getColumn(2).setPreferredWidth(20);
            tbListaCompras.getColumnModel().getColumn(3).setPreferredWidth(40);
        }

        jButton1.setText("Volver al menu");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 760, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(380, 380, 380)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1MouseClicked

    /**
     * @param args the command line arguments
     */
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbListaCompras;
    // End of variables declaration//GEN-END:variables
}
