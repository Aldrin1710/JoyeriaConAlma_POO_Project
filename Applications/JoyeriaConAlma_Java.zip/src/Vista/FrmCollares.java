/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Modelo.Carrito;
import Modelo.Cliente;
import Modelo.Collares;
import javax.swing.JOptionPane;

/**
 *
 * @author aldri
 */
public class FrmCollares extends javax.swing.JFrame {
    
   
    
    private Cliente cliente;  // Variable para almacenar el carrito
    
    public FrmCollares(Cliente cliente) {
        this.cliente = cliente; //se guarda la instancia recibida 
        
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        label_Nombre = new javax.swing.JLabel();
        label_ID = new javax.swing.JLabel();
        label_Descripcion = new javax.swing.JLabel();
        label_costo = new javax.swing.JLabel();
        label_tipoMaterial = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btAgregarArticulo = new javax.swing.JButton();
        cbCantidad = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        btSalir = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        label_tipoMaterial1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        label_Nombre2 = new javax.swing.JLabel();
        label_ID2 = new javax.swing.JLabel();
        label_Descripcion2 = new javax.swing.JLabel();
        label_costo2 = new javax.swing.JLabel();
        label_tipoMaterial2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btAgregarArticulo2 = new javax.swing.JButton();
        cbCantidad2 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        label_tipoMaterial3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setMinimumSize(new java.awt.Dimension(40, 40));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(850, 1000));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(900, 1000));
        jPanel1.setPreferredSize(new java.awt.Dimension(850, 1000));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/collares.jpg"))); // NOI18N

        label_Nombre.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_Nombre.setText("Collar de Coral ");

        label_ID.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_ID.setText("12345");

        label_Descripcion.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_Descripcion.setText("Collar de filigrana lleno de bolitas de color coral material de calidad");

        label_costo.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_costo.setText("160");

        label_tipoMaterial.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_tipoMaterial.setText("$");

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel2.setText("Material:");

        btAgregarArticulo.setText("Agregar al carrito");
        btAgregarArticulo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btAgregarArticuloMouseClicked(evt);
            }
        });
        btAgregarArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAgregarArticuloActionPerformed(evt);
            }
        });

        cbCantidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5" }));

        jPanel2.setBackground(new java.awt.Color(204, 153, 0));

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Nuestros Productos en Collares");

        btSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/salir_Img.png"))); // NOI18N
        btSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btSalirMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(182, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(101, 101, 101)
                .addComponent(btSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(110, 110, 110))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btSalir)
                    .addComponent(jLabel5))
                .addGap(43, 43, 43))
        );

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel7.setText("ID:");

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel8.setText("Nombre:");

        jLabel9.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel9.setText("Descripcion:");

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel10.setText("Cantidad:");

        jLabel11.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel11.setText("Costo:");

        label_tipoMaterial1.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_tipoMaterial1.setText("Coral, fligrana ");

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Collares2_1.jpg"))); // NOI18N

        label_Nombre2.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_Nombre2.setText("Alma de Pavo Real");

        label_ID2.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_ID2.setText("293142");

        label_Descripcion2.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_Descripcion2.setText("Conjunto de joyería artesanal, compuesto por un collar y aretes.");

        label_costo2.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_costo2.setText("350");

        label_tipoMaterial2.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_tipoMaterial2.setText("$");

        jLabel13.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel13.setText("Material:");

        btAgregarArticulo2.setText("Agregar al carrito");
        btAgregarArticulo2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btAgregarArticulo2MouseClicked(evt);
            }
        });
        btAgregarArticulo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAgregarArticulo2ActionPerformed(evt);
            }
        });

        cbCantidad2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));

        jLabel14.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel14.setText("ID:");

        jLabel15.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel15.setText("Nombre:");

        jLabel16.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel16.setText("Descripcion:");

        jLabel17.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel17.setText("Cantidad:");

        jLabel18.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel18.setText("Costo:");

        label_tipoMaterial3.setFont(new java.awt.Font("Gadugi", 0, 16)); // NOI18N
        label_tipoMaterial3.setText("Metal en acabado dorado, trabajado en filigrana");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(39, 39, 39)
                        .addComponent(label_ID))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(35, 35, 35)
                        .addComponent(label_Nombre))
                    .addComponent(label_Descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(17, 17, 17)
                        .addComponent(cbCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(20, 20, 20)
                        .addComponent(label_tipoMaterial)
                        .addGap(1, 1, 1)
                        .addComponent(label_costo))
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(label_tipoMaterial1))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(500, 500, 500)
                .addComponent(btAgregarArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(39, 39, 39)
                        .addComponent(label_ID2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(35, 35, 35)
                        .addComponent(label_Nombre2))
                    .addComponent(jLabel16)
                    .addComponent(label_Descripcion2, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(17, 17, 17)
                        .addComponent(cbCantidad2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addGap(20, 20, 20)
                        .addComponent(label_tipoMaterial2)
                        .addGap(1, 1, 1)
                        .addComponent(label_costo2))
                    .addComponent(jLabel13)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(label_tipoMaterial3))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(510, 510, 510)
                .addComponent(btAgregarArticulo2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(label_ID))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(label_Nombre))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(label_Descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel9))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel10))
                            .addComponent(cbCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(label_tipoMaterial)
                            .addComponent(label_costo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(label_tipoMaterial1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addComponent(btAgregarArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(label_ID2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addComponent(label_Nombre2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(label_Descripcion2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel17))
                            .addComponent(cbCantidad2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addComponent(label_tipoMaterial2)
                            .addComponent(label_costo2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel13)
                        .addGap(9, 9, 9)
                        .addComponent(label_tipoMaterial3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(20, 20, 20)
                .addComponent(btAgregarArticulo2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 790, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btAgregarArticuloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btAgregarArticuloMouseClicked
        // TODO add your handling code here:
        
        String ID = this.label_ID.getText();
        String nombre = this.label_Nombre.getText();
        String descripcion = this.label_Descripcion.getText();
        String cantidadComboBox = cbCantidad.getSelectedItem().toString(); //pasar el valor del combo box a String
        int cantidad = Integer.parseInt(cantidadComboBox);
        double costo = Double.parseDouble(this.label_costo.getText());
        String material = this.label_tipoMaterial1.getText();
        
        //Creamos la instancia de tipo Collar
        
        Collares unCollar = new Collares(ID, nombre, descripcion, cantidad, costo, material);
        
        //Agregamos el collar al carrito
        
        cliente.getCarritoCompras().agregarProducto(unCollar); //agregamos el producto al carrito del cliente
        
        JOptionPane.showMessageDialog(rootPane, "El articulo se ha agregado al carrito");
      
        
    }//GEN-LAST:event_btAgregarArticuloMouseClicked

    private void btAgregarArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAgregarArticuloActionPerformed
        // TODO add your handling code here:

        
        
    }//GEN-LAST:event_btAgregarArticuloActionPerformed

    private void btAgregarArticulo2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btAgregarArticulo2MouseClicked
        // TODO add your handling code here:
        
         String ID = this.label_ID2.getText();
        String nombre = this.label_Nombre2.getText();
        String descripcion = this.label_Descripcion2.getText();
        String cantidadComboBox = cbCantidad2.getSelectedItem().toString(); //pasar el valor del combo box a String
        int cantidad = Integer.parseInt(cantidadComboBox);
        double costo = Double.parseDouble(this.label_costo2.getText());
        String material = this.label_tipoMaterial3.getText();
        
        //Creamos la instancia de tipo Collar
        
        Collares unCollar = new Collares(ID, nombre, descripcion, cantidad, costo, material);
        
        //Agregamos el collar al carrito
        
        cliente.getCarritoCompras().agregarProducto(unCollar); //agregamos el producto al carrito del cliente
        
        JOptionPane.showMessageDialog(rootPane, "El articulo se ha agregado al carrito");
        
        
    }//GEN-LAST:event_btAgregarArticulo2MouseClicked

    private void btAgregarArticulo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAgregarArticulo2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btAgregarArticulo2ActionPerformed

    private void btSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btSalirMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btSalirMouseClicked

 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAgregarArticulo;
    private javax.swing.JButton btAgregarArticulo2;
    private javax.swing.JLabel btSalir;
    private javax.swing.JComboBox<String> cbCantidad;
    private javax.swing.JComboBox<String> cbCantidad2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_Descripcion;
    private javax.swing.JLabel label_Descripcion2;
    private javax.swing.JLabel label_ID;
    private javax.swing.JLabel label_ID2;
    private javax.swing.JLabel label_Nombre;
    private javax.swing.JLabel label_Nombre2;
    private javax.swing.JLabel label_costo;
    private javax.swing.JLabel label_costo2;
    private javax.swing.JLabel label_tipoMaterial;
    private javax.swing.JLabel label_tipoMaterial1;
    private javax.swing.JLabel label_tipoMaterial2;
    private javax.swing.JLabel label_tipoMaterial3;
    // End of variables declaration//GEN-END:variables
}
