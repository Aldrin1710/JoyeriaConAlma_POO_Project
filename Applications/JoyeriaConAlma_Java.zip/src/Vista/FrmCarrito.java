/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Modelo.Accesorios;
import Modelo.Cliente;
import Modelo.Collares;
import Modelo.Material;
import Modelo.Peinetas;
import Modelo.PorMetro;
import Modelo.PorUnidad;
import Modelo.Producto;
import Modelo.Rebosos;
import Modelo.Rosarios;
import java.util.List;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aldri
 */
public class FrmCarrito extends javax.swing.JFrame {

    /**
     * Creates new form FrmCarrito
     */
    private Cliente cliente;
    
    public FrmCarrito(Cliente cliente) {
        this.cliente = cliente; //copiamos la instancia del cliente que recibimos
        initComponents();
        inicializaTabla();
        actualizarComboBox();
        
    }
    
    public void inicializaTabla(){
        
        DefaultTableModel modelo = (DefaultTableModel) tablaListaDeseo.getModel();
        
        //Creamos una lista con los productos
        
        List<Producto> listaProductos = cliente.getCarritoCompras().getListaProductos();

        for(int i = 0; i < listaProductos.size(); i++){
           
            Vector<Object> fila = new Vector<Object>();
            
            //Datos basicos de cualquier producto
            fila.add(listaProductos.get(i).getId());
            fila.add(listaProductos.get(i).getNombreProducto());
            fila.add(listaProductos.get(i).getDescripcion());
            
            //verificar si es de tipo Accesorio 
            if(listaProductos.get(i) instanceof Accesorios){
                //Serpiente unaSerpiente = (Serpiente) listaAnimal.get(i); //aplicamos Casting 
                Accesorios unAccesorio = (Accesorios) listaProductos.get(i); //casting
                
                fila.add(unAccesorio.getCantidad());
                fila.add(unAccesorio.getCosto());
                
                //Verificar si es una instancia de: 
                if(unAccesorio instanceof Collares){
                   Collares unCollar = (Collares) unAccesorio;
                   fila.add(unCollar.getTipoAlambre());
                }
                //Verificar instancia de Peinetas
                if(unAccesorio instanceof Peinetas){
                    Peinetas unaPeineta = (Peinetas) unAccesorio;
                    fila.add(unaPeineta.getTamanio());
                }
                //Verificar instancia de Rosarios
                if(unAccesorio instanceof Rosarios){
                    Rosarios unRosario = (Rosarios) unAccesorio;
                    fila.add(unRosario.getDetalles());
                } 
                //Verificar si es un reboso
                if(unAccesorio instanceof Rebosos){
                    Rebosos unReboso = (Rebosos) unAccesorio;
                    fila.add(unReboso.getTamanio());
                }
                
                
            } else if(listaProductos.get(i) instanceof Material){
                Material unMaterial = (Material) listaProductos.get(i); //casting
                
                if(unMaterial instanceof PorUnidad){
                    PorUnidad unaUnidad = (PorUnidad) unMaterial;
                    fila.add(unaUnidad.getNumUnidades());
                    fila.add(unaUnidad.getCostoUnidad());
                    fila.add(unaUnidad.getTipoMaterial() + " " + unaUnidad.getTamanio()); //Juntamos el material y tamanio
                    
                } else if(unMaterial instanceof PorMetro){
                    PorMetro unMetro = (PorMetro) unMaterial;
                    fila.add(unMetro.getNumMetros());
                    fila.add(unMetro.getCostoMetro());
                    fila.add(unMetro.getTipoMaterial());
                }
            }
            
            fila.add(listaProductos.get(i).calcularCostoTotal()); //Calculamos el costo total del articulo
            
           
            
            modelo.addRow(fila);
        }
    }
    
    
    private void actualizarComboBox(){ 
        //Metodo que actualiza el comboBox con los elementos restantes de la nueva tabla
        List<Producto> listaProductos = cliente.getCarritoCompras().getListaProductos();
        comboBoxArticulos.removeAllItems();
        comboBoxArticulos.addItem("--");
        for (int i = 0; i < listaProductos.size(); i++) {
            String item = listaProductos.get(i).getNombreProducto();
            comboBoxArticulos.addItem(item);
        }
        
    }
    
    private void actualizarTabla(){
        //Metodo para actualizar la tabla sin el elemento eliminado en la lista
        
        DefaultTableModel nuevoModelo = (DefaultTableModel) tablaListaDeseo.getModel();
        nuevoModelo.setRowCount(0); // Limpia todas las filas de la tabla

        // Creamos una lista con los productos
        List<Producto> listaProductos = cliente.getCarritoCompras().getListaProductos();

        for (int i = 0; i < listaProductos.size(); i++) {

            Vector<Object> fila = new Vector<Object>();

        // Datos basicos de cualquier producto
            fila.add(listaProductos.get(i).getId());
            fila.add(listaProductos.get(i).getNombreProducto());
            fila.add(listaProductos.get(i).getDescripcion());

        // Verificar si es de tipo Accesorio 
            if (listaProductos.get(i) instanceof Accesorios) {
                Accesorios unAccesorio = (Accesorios) listaProductos.get(i); // casting

                fila.add(unAccesorio.getCantidad());
                fila.add(unAccesorio.getCosto());

            // Verificar si es una instancia de:
            if (unAccesorio instanceof Collares) {
                Collares unCollar = (Collares) unAccesorio;
                fila.add(unCollar.getTipoAlambre());
            }
            // Verificar instancia de Peinetas
            if (unAccesorio instanceof Peinetas) {
                Peinetas unaPeineta = (Peinetas) unAccesorio;
                fila.add(unaPeineta.getTamanio());
            }
            // Verificar instancia de Rosarios
            if (unAccesorio instanceof Rosarios) {
                Rosarios unRosario = (Rosarios) unAccesorio;
                fila.add(unRosario.getDetalles());
            } 
            // Verificar si es un reboso
            if (unAccesorio instanceof Rebosos) {
                Rebosos unReboso = (Rebosos) unAccesorio;
                fila.add(unReboso.getTamanio());
            }

        } else if (listaProductos.get(i) instanceof Material) {
            Material unMaterial = (Material) listaProductos.get(i); // casting

            if (unMaterial instanceof PorUnidad) {
                PorUnidad unaUnidad = (PorUnidad) unMaterial;
                fila.add(unaUnidad.getNumUnidades());
                fila.add(unaUnidad.getCostoUnidad());
                fila.add(unaUnidad.getTipoMaterial() + " " + unaUnidad.getTamanio()); // Juntamos el material y tamaño

            } else if (unMaterial instanceof PorMetro) {
                PorMetro unMetro = (PorMetro) unMaterial;
                fila.add(unMetro.getNumMetros());
                fila.add(unMetro.getCostoMetro());
                fila.add(unMetro.getTipoMaterial());
            }
    }

            fila.add(listaProductos.get(i).calcularCostoTotal()); // Calculamos el costo total del artículo

            nuevoModelo.addRow(fila);
        
            
        }

    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaListaDeseo = new javax.swing.JTable();
        btVolverMenu = new javax.swing.JButton();
        btComprar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        comboBoxArticulos = new javax.swing.JComboBox<>();
        btBorrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(204, 153, 0));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        jLabel1.setText("CARRITO DE COMPRAS");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(336, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(279, 279, 279))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        tablaListaDeseo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Descripcion", "Cantidad", "Costo", "Extras", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaListaDeseo.setRowHeight(20);
        jScrollPane1.setViewportView(tablaListaDeseo);
        if (tablaListaDeseo.getColumnModel().getColumnCount() > 0) {
            tablaListaDeseo.getColumnModel().getColumn(0).setResizable(false);
            tablaListaDeseo.getColumnModel().getColumn(0).setPreferredWidth(25);
            tablaListaDeseo.getColumnModel().getColumn(1).setResizable(false);
            tablaListaDeseo.getColumnModel().getColumn(1).setPreferredWidth(85);
            tablaListaDeseo.getColumnModel().getColumn(2).setResizable(false);
            tablaListaDeseo.getColumnModel().getColumn(2).setPreferredWidth(230);
            tablaListaDeseo.getColumnModel().getColumn(3).setResizable(false);
            tablaListaDeseo.getColumnModel().getColumn(3).setPreferredWidth(10);
            tablaListaDeseo.getColumnModel().getColumn(4).setResizable(false);
            tablaListaDeseo.getColumnModel().getColumn(4).setPreferredWidth(15);
            tablaListaDeseo.getColumnModel().getColumn(5).setResizable(false);
            tablaListaDeseo.getColumnModel().getColumn(5).setPreferredWidth(140);
            tablaListaDeseo.getColumnModel().getColumn(6).setResizable(false);
            tablaListaDeseo.getColumnModel().getColumn(6).setPreferredWidth(20);
        }

        btVolverMenu.setText("Volver");
        btVolverMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btVolverMenuMouseClicked(evt);
            }
        });

        btComprar.setText("COMPRAR");
        btComprar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btComprarMouseClicked(evt);
            }
        });
        btComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btComprarActionPerformed(evt);
            }
        });

        jLabel2.setText("Eliminar Producto");

        comboBoxArticulos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--" }));
        comboBoxArticulos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboBoxArticulosMouseClicked(evt);
            }
        });
        comboBoxArticulos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxArticulosActionPerformed(evt);
            }
        });

        btBorrar.setText("Borrar");
        btBorrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btBorrarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 848, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(730, 730, 730)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(420, 420, 420)
                .addComponent(btComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(147, 147, 147)
                .addComponent(comboBoxArticulos, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(740, 740, 740)
                .addComponent(btBorrar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btVolverMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jLabel2)
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(btComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(comboBoxArticulos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(btBorrar)
                .addGap(0, 0, 0)
                .addComponent(btVolverMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btVolverMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btVolverMenuMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btVolverMenuMouseClicked

    private void comboBoxArticulosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxArticulosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxArticulosActionPerformed

    private void comboBoxArticulosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboBoxArticulosMouseClicked
      
    }//GEN-LAST:event_comboBoxArticulosMouseClicked

    private void btBorrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btBorrarMouseClicked
        // Evento para borrar elementos del carrito: usando el comboBoxArticulos
        String seleccionComboBox = comboBoxArticulos.getSelectedItem().toString(); //pasar el valor del combo box a String
        List<Producto> productosCarrito = cliente.getCarritoCompras().getListaProductos();
        
        for (int i = 0; i < productosCarrito.size(); i++) {
            Producto productoSeleccionado = productosCarrito.get(i); //Creamos una instancia Producto para la comparacion
            
            //Se compara con el metodo equals() si la seleccion se encuentra en la lista (aunque ya sabemos que asi sera)
            if(seleccionComboBox.equals(productoSeleccionado.getNombreProducto())){
                productosCarrito.remove(i); //Si se cumple, removemos el producto de la lista
                
                //Metodos para actualizar los datos 
                actualizarTabla();
                actualizarComboBox();
            }
        }
        
    }//GEN-LAST:event_btBorrarMouseClicked

    private void btComprarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btComprarMouseClicked
        // Metodo para el frame Transaccion
        
        //Verificar si el carrito esta vacio
        int cantidadProductosCarrito = cliente.getCarritoCompras().getListaProductos().size();
        
        if(cantidadProductosCarrito != 0){
            FrmTransaccion frameTransaccion = new FrmTransaccion(cliente);
            frameTransaccion.setVisible(true);
            this.dispose();
        } else{
            JOptionPane.showMessageDialog(rootPane, "El carrito esta vacio ");
        }
        
        
    }//GEN-LAST:event_btComprarMouseClicked

    private void btComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btComprarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btComprarActionPerformed

    
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btBorrar;
    private javax.swing.JButton btComprar;
    private javax.swing.JButton btVolverMenu;
    private javax.swing.JComboBox<String> comboBoxArticulos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaListaDeseo;
    // End of variables declaration//GEN-END:variables
}
