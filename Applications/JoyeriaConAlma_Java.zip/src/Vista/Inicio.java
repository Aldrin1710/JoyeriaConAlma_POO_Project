/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Vista;

import Modelo.Administrador;
import Modelo.Cliente;
import Modelo.Datos;
import static Modelo.Datos.listaClientes;
import static Modelo.DatosAdmin.listaAdministradores;
import Modelo.DatosAdmin;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author aldri
 */
public class Inicio {
  
    //Declaramos las listas de datos usados para Guardar los datos de los clientes y los admins
    public static Datos data = new Datos(); 
    public static DatosAdmin dataAdmin = new DatosAdmin();
    private static final String NOMBRE_ARCHIVO = "DatosCliente.data";
    private static final String NOMBRE_ARCHIVO2= "DatosAdministrador.data";

public static void main(String[] args) throws ClassNotFoundException {
    // TODO code application logic here
    
    // AGREGAR UN CLIENTE DEFINIDO SOLO PARA PRUEBAS  
    listaClientes.add(new Cliente("aldrin", "novelo", "gongora", "1", "1"));
     cargarDatos();
    
    
     // Guardar el archivo actualizado (incluyendo el cliente predefinido)
    listaAdministradores.add(new Administrador("erick","vega","nolasco","2","2","2","2/nov/2024"));
     cargarDatos2();
   
    // Inicializar el frame del inicio
    new FrmInicio(data, dataAdmin).setVisible(true); 
}
 public static void guardarDatos() {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(NOMBRE_ARCHIVO))) {
            salida.writeObject(listaClientes);
            System.out.println("Datos guardados correctamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar los datos: " + e.getMessage());
        }
    }

    // Método para cargar datos desde el archivo binario
    public static void cargarDatos() {
        File archivo = new File(NOMBRE_ARCHIVO);
        if (archivo.exists()) {
            try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(NOMBRE_ARCHIVO))) {
                listaClientes = (ArrayList<Cliente>) entrada.readObject();
                System.out.println("Datos cargados correctamente.");
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("Error al cargar los datos: " + e.getMessage());
            }
        } else {
            System.out.println("No se encontraron datos previos.");
        }
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(NOMBRE_ARCHIVO))) {
            ArrayList<Cliente> listaPorPagar= (ArrayList<Cliente>) entrada.readObject();
            entrada.close();
            System.out.println(listaPorPagar);
        }
        catch(IOException e1){
            System.out.println("Imposible leer el archivo");
        }
        catch(ClassNotFoundException ex){
            System.out.println("El objeto leido no corresponde a la clase");
        }
    }
        
        // GuardaR y cargar admin     
    public static void guardarDatos2() {
        try (ObjectOutputStream salida2 = new ObjectOutputStream(new FileOutputStream(NOMBRE_ARCHIVO2))) {
            salida2.writeObject(listaAdministradores);
            System.out.println("Datos guardados correctamente. archivo2");
        } catch (IOException e8) {
            System.out.println("Error al guardar los datos:archivo2 " + e8.getMessage());
        }
    }

    // Método para cargar datos desde el archivo binario
    public static void cargarDatos2() {
        File archivo2 = new File(NOMBRE_ARCHIVO2);
        if (archivo2.exists()) {
            try (ObjectInputStream entrada2 = new ObjectInputStream(new FileInputStream(NOMBRE_ARCHIVO2))) {
                listaAdministradores = (ArrayList<Administrador>) entrada2.readObject();
                System.out.println("Datos cargados correctamente.archivo 2");
            } catch (IOException | ClassNotFoundException e5) {
                System.out.println("Error al cargar los datos: archivo 2" + e5.getMessage());
            }
        } else {
            System.out.println("No se encontraron datos previos. archivo 2");
        }
        try (ObjectInputStream entrada2 = new ObjectInputStream(new FileInputStream(NOMBRE_ARCHIVO2))) {
            ArrayList<Administrador> listaAdministradores= (ArrayList<Administrador>) entrada2.readObject();
            entrada2.close();
            System.out.println(listaAdministradores);
        }
        catch(IOException e5){
            System.out.println("Imposible leer el archivo 2");
        }
        catch(ClassNotFoundException e6){
            System.out.println("El objeto leido no corresponde a la clase archivo2");
        }
    }
}
