/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Modelo.Cliente;
import Modelo.Compra;
import Modelo.Pago;
import Modelo.Producto;
import static java.lang.Double.parseDouble;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author aldri
 */
public class FrmTransaccion extends javax.swing.JFrame {

    /**
     * Creates new form FrmTransaccion
     */
    private Cliente cliente;
    public FrmTransaccion(Cliente cliente) {
        this.cliente = cliente; //copiamos la instancia del cliente con el que venimos trabajando
        
        initComponents();
        String texto = calcularCostoTotal(); //llmamos al Jlabel que imprime el costo total
        this.labelCostoTotal.setText("$" + texto);
        actualizarListaArticulos();
    }
    

    private void actualizarListaArticulos(){
        List<Producto> productos = cliente.getCarritoCompras().getListaProductos();

        // Creamos un modelo de lista para manejar los elementos
        DefaultListModel<String> modeloLista = new DefaultListModel<>();

        // Limpiamos el modelo
        modeloLista.clear();

        // Agregamos los elementos al modelo
        for (Producto producto : productos) {
            modeloLista.addElement(producto.getNombreProducto());
        }

        // Configuramos el modelo en el JList
        listArticulos.setModel(modeloLista);
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        labelCostoTotal = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtCP = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbTipoTarjeta = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        txtNumTarjeta = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtCVV = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cbMesVencimiento = new javax.swing.JComboBox<>();
        cbAnioVencimiento = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listArticulos = new javax.swing.JList<>();
        btConfirmarCompra = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("TOTAL COMPRAS: ");

        labelCostoTotal.setFont(new java.awt.Font("Dubai Medium", 0, 14)); // NOI18N
        labelCostoTotal.setText("-------");

        jPanel2.setBackground(new java.awt.Color(204, 153, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 85, Short.MAX_VALUE)
        );

        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("DIRECCION: ");

        jLabel3.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("INFO PERSONAL:");

        jLabel4.setForeground(new java.awt.Color(153, 153, 153));
        jLabel4.setText("CODIGO POSTAL:");

        jLabel5.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("INFO PAGO");

        jLabel6.setForeground(new java.awt.Color(153, 153, 153));
        jLabel6.setText("TIPO DE TARJETA");

        cbTipoTarjeta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Visa", "Mastercard", "AMEX", "Banco Azteca", " ", " " }));

        jLabel7.setForeground(new java.awt.Color(153, 153, 153));
        jLabel7.setText("No. TARJETA");

        jLabel8.setForeground(new java.awt.Color(153, 153, 153));
        jLabel8.setText("CVV:");

        jLabel9.setForeground(new java.awt.Color(153, 153, 153));
        jLabel9.setText("FECHA VENCIMIENTO:");

        cbMesVencimiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 (enero)", "2 (febrero)", "3 (marzo)", "4 (abril)", "5 ( mayo)", "6 (junio)", "7 (julio)", "8 (agosto)", "9 (septiembre)", "10 (octubre)", "11 (noviembre)", "12 (diciembre)" }));

        cbAnioVencimiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032" }));

        jLabel10.setForeground(new java.awt.Color(153, 153, 153));
        jLabel10.setText("ARTICULOS SELECCIONADOS:");

        listArticulos.setBackground(new java.awt.Color(255, 255, 255));
        listArticulos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Non-selection yet" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listArticulos);

        btConfirmarCompra.setBackground(new java.awt.Color(255, 51, 0));
        btConfirmarCompra.setText("CONFIRMAR COMPRA");
        btConfirmarCompra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btConfirmarCompraMouseClicked(evt);
            }
        });

        jButton1.setText("Volver");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 245, Short.MAX_VALUE)
                        .addComponent(labelCostoTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(73, 73, 73))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtCP, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cbTipoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel7))))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel8)
                                .addComponent(txtNumTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtCVV, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addComponent(jLabel9))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbMesVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(27, 27, 27)
                                        .addComponent(cbAnioVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel10))
                                        .addGap(33, 33, 33))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btConfirmarCompra)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(17, 17, 17)))
                                        .addGap(45, 45, 45))))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelCostoTotal)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel10))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtCP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbTipoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btConfirmarCompra))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCVV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbMesVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbAnioVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1MouseClicked

    private void btConfirmarCompraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConfirmarCompraMouseClicked
        //Event: Confirmar Compra
    
        //Validacion de campos obligatorios
        if (txtDireccion.getText().trim().isEmpty() || txtCP.getText().trim().isEmpty() ||
            txtNumTarjeta.getText().trim().isEmpty() || txtCVV.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(rootPane, "Todos los campos son obligatorios");
            return; // Termina el metodo si hay campos vacios
        }

        //Guardamos los datos de la compra 
        String datosDireccion = this.txtDireccion.getText() + " CP: " + this.txtCP.getText();
        cliente.setDireccion(datosDireccion); //Agregamos la direccion al cliente

        //Datos de pago
        String tipoTarjeta = cbTipoTarjeta.getSelectedItem().toString();
        String numTarjeta = this.txtNumTarjeta.getText();
        String cvv = this.txtCVV.getText();
        String mesVencimiento = cbMesVencimiento.getSelectedItem().toString();
        String anioVencimiento = cbAnioVencimiento.getSelectedItem().toString();

        Pago unaTransaccion = new Pago(tipoTarjeta, numTarjeta, cvv, mesVencimiento, anioVencimiento);
        double pago_total = (double) parseDouble(calcularCostoTotal());
        
        //Pre-verificacion de la lista
        if (cliente.getCarritoCompras().getListaProductos()== null || cliente.getCarritoCompras().getListaProductos().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: la lista de productos esta vacia o es null", 
                                          "Error", JOptionPane.ERROR_MESSAGE);
        }

        //Obtenemos productos del carrito y creamos la compra
        //Guardamos mediante una copia
        ArrayList<Producto> productosComprados  = new ArrayList<>(cliente.getCarritoCompras().getListaProductos());
        
        // Verificar si la lista tiene productos
        if (productosComprados != null && !productosComprados.isEmpty()) {
            // Crear un StringBuilder para almacenar los nombres de los productos
            StringBuilder mensaje = new StringBuilder("Productos comprados:\n");

            // Añadir los nombres de los productos al mensaje
            for (Producto producto : productosComprados) {
                mensaje.append("- ").append(producto.getNombreProducto()).append("\n");
            }

            // Mostrar el mensaje en un cuadro de diálogo
            JOptionPane.showMessageDialog(null, mensaje.toString(), "Productos Comprados", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Mostrar un mensaje de alerta si el carrito está vacío
            JOptionPane.showMessageDialog(null, "El carrito está vacio o no se han agregado productos.", "Carrito Vacio", JOptionPane.WARNING_MESSAGE);
        }

        
        Compra unaCompra = new Compra(productosComprados, unaTransaccion, pago_total);

        //Agregamos la compra a la lista de compras del cliente y vaciamos el carrito
        cliente.getCompras().add(unaCompra);
        
        cliente.getCarritoCompras().vaciarCarrito();
      
        JOptionPane.showMessageDialog(rootPane, "Compra realizada exitosamente");
        this.dispose();

    }//GEN-LAST:event_btConfirmarCompraMouseClicked

    /**
     * @param args the command line arguments
     */
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btConfirmarCompra;
    private javax.swing.JComboBox<String> cbAnioVencimiento;
    private javax.swing.JComboBox<String> cbMesVencimiento;
    private javax.swing.JComboBox<String> cbTipoTarjeta;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelCostoTotal;
    private javax.swing.JList<String> listArticulos;
    private javax.swing.JTextField txtCP;
    private javax.swing.JTextField txtCVV;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNumTarjeta;
    // End of variables declaration//GEN-END:variables

    private  String calcularCostoTotal() {
       List<Producto> listaProductosParaComprar = cliente.getCarritoCompras().getListaProductos();  
       Double costo_total = 0.0;
       
        for (int i = 0; i < listaProductosParaComprar.size() ; i++) {
            Producto productoSeleccionado = listaProductosParaComprar.get(i); //intanciamos el elemetno de la lista a ProductoSeleccionado
            
            //Ahora, accedemos al metodo del costo total de cada articulo seleccionado
            Double costo_parcial = productoSeleccionado.calcularCostoTotal();
            
            costo_total = costo_total + costo_parcial;
            
        }
        
        //Luego que tengamos el costo total de los articulos, pasamos el dato a String para mostrarlo en el label
        String cadena_costoTotal = String.valueOf(costo_total);
        
        return cadena_costoTotal; //retornamos el valor de la cadena :)
    }
}
