/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public abstract class Accesorios extends Producto{
    
    //Atributos
    protected int cantidad;
    protected double costo;
    
    //Constructor
    public Accesorios(String id, String nombreProducto, String descripcion, int cantidad, double costo) {
        super(id, nombreProducto, descripcion);
        this.cantidad = cantidad;
        this.costo = costo;
    }
    
    //Getters
    public int getCantidad() {
        return cantidad;
    }

    public double getCosto() {
        return costo;
    }
    
    //Setters
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }
    
    //toString

    @Override
    public String toString() {
        return super.toString() + "cantidad=" + cantidad + ", costo=" + costo + '}';
    }
    
    
}
