package Modelo;

public class Queja {
    private String nombre;
    private String correo;
    private String descripcion;

    public Queja(String nombre, String correo, String descripcion) {
        this.nombre = nombre;
        this.correo = correo;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
