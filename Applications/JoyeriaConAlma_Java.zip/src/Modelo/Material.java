/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public abstract class Material extends Producto{
    
    //Atributos
    protected String tipoMaterial;
    
    //Constructor
    public Material(String id, String nombreProducto, String descripcion, String tipoMaterial) {
        super(id, nombreProducto, descripcion);
        this.tipoMaterial = tipoMaterial;
    }

    public String getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(String tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    @Override
    public String toString() {
        return super.toString() + "tipoMaterial=" + tipoMaterial + '}';
    }
    
    
    
}
