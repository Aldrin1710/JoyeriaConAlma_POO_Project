/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Rebosos extends Accesorios{
    
    protected String tamanio;
    

    public Rebosos(String id, String nombreProducto, String descripcion, int cantidad, double costo, String tamanio) {
        super(id, nombreProducto, descripcion, cantidad, costo);
        this.tamanio = tamanio;
      
    }

    public String getTamanio() {
        return tamanio;
    }

    public void setTamanio(String tamanio) {
        this.tamanio = tamanio;
    }
    
    //metodo abstracto
    @Override
    public double calcularCostoTotal() {
        return costo * cantidad;
    }

    @Override
    public String toString() {
        return super.toString() + "Rebosos{" + "tamanio" + tamanio;
    }
    
    
    
    
}
