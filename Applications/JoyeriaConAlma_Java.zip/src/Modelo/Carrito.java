/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aldri
 */
public class Carrito implements Serializable{
   
    
    //Agregar producto al carrito
    ArrayList<Producto> listaProductos = new ArrayList();

    public ArrayList<Producto> getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(ArrayList<Producto> listaProductos) {
        this.listaProductos = listaProductos;
    }
    
    
    
    public Carrito() {
        listaProductos = new ArrayList<>();
    }
    
    //Metodo agregar cuenta cliente
    public void agregarProducto(Producto unProducto){
        listaProductos.add(unProducto);
    }
    
    
    
    // Vaciar el carrito
    public void vaciarCarrito() {
        this.listaProductos.clear(); // Esto elimina todos los elementos en la lista
    }
    
}
