/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Alambre extends PorMetro{

    public Alambre(String id, String nombreProducto, String descripcion, String tipoMaterial, double numMetros, double costoMetro) {
        super(id, nombreProducto, descripcion, tipoMaterial, numMetros, costoMetro);
    }
    
    //metodo abstracto calcularCostoTotal()
    public double calcularCostoTotal() {
        
        double costo_final = numMetros * costoMetro;
        
        //Si el numero de metros excede a 20 se le aplicara un 10% de descuento
        if(numMetros >= 20){
            costo_final = costo_final * 0.9;
        }
        return costo_final;
    }
}
