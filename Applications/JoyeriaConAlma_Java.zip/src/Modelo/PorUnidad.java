/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public abstract class PorUnidad extends Material{
    //Atributos
    protected int numUnidades;
    protected double costoUnidad;
    protected String tamanio;
    

    public PorUnidad(String id, String nombreProducto, String descripcion, String tipoMaterial, int numUnidades, double costoUnidad ,String tamanio) {
        super(id, nombreProducto, descripcion, tipoMaterial);
        this.numUnidades = numUnidades;
        this.costoUnidad = costoUnidad;
        this.tamanio = tamanio;
    }

    public int getNumUnidades() {
        return numUnidades;
    }

    public double getCostoUnidad() {
        return costoUnidad;
    }

    public String getTamanio() {
        return tamanio;
    }

    public void setNumUnidades(int numUnidades) {
        this.numUnidades = numUnidades;
    }

    public void setCostoUnidad(double costoUnidad) {
        this.costoUnidad = costoUnidad;
    }

    public void setTamanio(String tamanio) {
        this.tamanio = tamanio;
    }

    @Override
    public String toString() {
        return super.toString() + "PorUnidad{" + "numUnidades=" + numUnidades + ", costoUnidad=" + costoUnidad + ", tama\u00f1o=" + tamanio + '}';
    }
    
}
