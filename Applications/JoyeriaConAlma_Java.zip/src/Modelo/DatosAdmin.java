/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import Modelo.Administrador;

public class DatosAdmin {


    public static ArrayList<Administrador> listaAdministradores = new ArrayList<>();
    
    
    //Metodo para agregar un admin a la lista
    public void agregarAdmin(Administrador AdminAgregado){
        listaAdministradores.add(AdminAgregado);
    }
    
    public DatosAdmin(){
    
    }
    
    // Método para buscar un administrador
    public Administrador buscarAdministrador(String unCorreo, String unaPassword, String unID) {
        for (int i = 0; i < listaAdministradores.size(); i++) {
            Administrador unAdministrador = listaAdministradores.get(i);
            // Validación del correo, contraseña e ID
            if (unAdministrador.getCorreo().equals(unCorreo) &&
                unAdministrador.getPassword().equals(unaPassword) &&
                unAdministrador.getID().equals(unID)) {
                return unAdministrador; // Si cumple todas las validaciones
            }
        }
        return null; // Si no se encuentra, retorna null
    }

    public void add(Administrador administrador) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
   
    
}
