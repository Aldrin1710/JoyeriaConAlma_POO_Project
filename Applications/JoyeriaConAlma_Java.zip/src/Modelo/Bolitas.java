/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Bolitas extends PorUnidad{

    public Bolitas(String id, String nombreProducto, String descripcion, String tipoMaterial, int numUnidades, double costoUnidad, String tamanio) {
        super(id, nombreProducto, descripcion, tipoMaterial, numUnidades, costoUnidad, tamanio);
    }
    
    //metodo abstracto calcularCostoTotal()
    public double calcularCostoTotal() {
        return numUnidades * costoUnidad;
    }
}
