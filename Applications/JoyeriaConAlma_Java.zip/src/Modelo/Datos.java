/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author aldri
 */
public class Datos {
    
    //Manejo del flujo de los clientes registrados
    
    public static ArrayList<Cliente> listaClientes = new ArrayList();
    
    //Getters y setters
    public static ArrayList<Cliente> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }
    
    
    
    //Metodo agregar cuenta cliente
    public void agregarCliente(Cliente clienteAgregado){
        listaClientes.add(clienteAgregado);
    }
    
    //Metodo para buscar un cliente
    public Cliente buscarCliente(String unCorreo, String unaPassword){
     
        for (int i = 0; i < listaClientes.size(); i++) {
            Cliente unCliente = listaClientes.get(i);
            //Validacion del correo y contraseña
            if(unCliente.getCorreo().equals(unCorreo)){
                if (unCliente.getPassword().equals(unaPassword)) {
                    
                    return unCliente; //Si cumple la validacion
                }   
            }
            
        }
        return null;
    }
    
     // Mostrar todos los clientes
    public void mostrarClientes() {
        for(int j=0; j < listaClientes.size(); j++){
            System.out.println(listaClientes.get(j));
        }
    }

    
    
    
}
