/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author aldri
 */
public class Cliente extends Persona{
    
    //Atributo 
    protected String direccion;
    protected Carrito carritoCompras;
    protected List<Compra> compras;

    //Constructor vacio
    
    
    public Cliente() {
        super(); // Llama al constructor vacío de Persona
        this.direccion = "";
        this.carritoCompras = new Carrito(); // Inicializa el carrito vacío
        this.compras = new ArrayList<>(); // Inicializa la lista de compras
    }
    
    //Constructor
    public Cliente(String nombre, String apellidoPaterno, String apellidoMaterno, String correo, String password) {
        super(nombre, apellidoPaterno, apellidoMaterno, correo, password);
        this.direccion = ""; //inicializamos constructor vacio
        this.carritoCompras = new Carrito(); // Inicializa el carrito vacío
        this.compras = new ArrayList<>(); // Inicializa la lista de compras
    }
    
    //Getters
    
    public Carrito getCarritoCompras() {
        return carritoCompras;
    }

    public String getDireccion() {
        return direccion;
    }

    public List<Compra> getCompras() {
        return compras;
    }
    
    //Setters
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setCarritoCompras(Carrito carritoCompras) {
        this.carritoCompras = carritoCompras;
    }

    public void setCompras(List<Compra> compras) {
        this.compras = compras;
    }

    @Override
    public String toString() {
        return super.toString() +  " direccion=" + direccion + ", carritoCompras=" + carritoCompras + ", compras= " + compras + '}';
    }
    
  
    
}
