/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public abstract class PorMetro extends Material{
    
    //atributos
    protected double numMetros;
    protected double costoMetro;

    public PorMetro(String id, String nombreProducto, String descripcion, String tipoMaterial, double numMetros, double costoMetro) {
        super(id, nombreProducto, descripcion, tipoMaterial);
        this.numMetros = numMetros;
        this.costoMetro = costoMetro;
    }

    public double getNumMetros() {
        return numMetros;
    }

    public void setNumMetros(double numMetros) {
        this.numMetros = numMetros;
    }

    public double getCostoMetro() {
        return costoMetro;
    }

    public void setCostoMetro(double costoMetro) {
        this.costoMetro = costoMetro;
    }

    @Override
    public String toString() {
        return super.toString() + "PorMetro{" + "numMetros=" + numMetros + ", costoMetro=" + costoMetro + '}';
    }
    
    
}
