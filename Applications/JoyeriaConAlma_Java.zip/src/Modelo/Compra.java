/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aldri
 */
import java.io.Serializable;
import java.util.ArrayList;

public class Compra implements Serializable {
    // Atributos
    protected ArrayList<Producto> productosComprados; // Cambiado a ArrayList
    protected Pago transaccion;
    protected double pago_total;

    // Constructor
    public Compra(ArrayList<Producto> productosComprados, Pago transaccion, double pago_total) {
        this.productosComprados = productosComprados;
        this.transaccion = transaccion;
        this.pago_total = pago_total;
    }

    // Metodos
    public ArrayList<Producto> getProductosComprados() {
        return productosComprados;
    }

    public String obtenerNombreProducto() {
    StringBuilder nombresProductos = new StringBuilder();  // Usamos StringBuilder para la concatenación eficiente

    // Iteramos sobre todos los productos de la lista
    for (Producto producto : productosComprados) {
        if (producto != null && producto.getNombreProducto() != null) {
            nombresProductos.append(producto.getNombreProducto()).append(" ");  // Agregamos el nombre del producto y un espacio
        }
    }

    if (nombresProductos.length() == 0) {
        return "No existen productos en la lista :cc";
    }

        return nombresProductos.toString();
    }
    
    //Getters y setters
    public void setProductosComprados(ArrayList<Producto> productosComprados) {
        this.productosComprados = productosComprados;
    }

    public Pago getTransaccion() {
        return transaccion;
    }

    public void setTransaccion(Pago transaccion) {
        this.transaccion = transaccion;
    }

    public double getPago_total() {
        return pago_total;
    }

    public void setPago_total(double pago_total) {
        this.pago_total = pago_total;
    }
}
