/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Peinetas extends Accesorios{
    
    protected String tamanio;

    public Peinetas(String id, String nombreProducto, String descripcion, int cantidad, double costo,String tamanio) {
        super(id, nombreProducto, descripcion, cantidad, costo);
        this.tamanio = tamanio;
    }

    public String getTamanio() {
        return tamanio;
    }

    public void setTamaño(String tamanio) {
        this.tamanio = tamanio;
    }
    
    //metodo abstracto

    @Override
    public double calcularCostoTotal() {
        return cantidad * costo;
    }

    @Override
    public String toString() {
        return super.toString() + "Peinetas{" + "tamanio=" + tamanio + '}';
    }
    
    
    
    
}
