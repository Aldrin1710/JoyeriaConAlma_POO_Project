/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Pago {
    
    //Atributos
    protected String tipoTarjeta;
    protected String numTarjeta;
    protected String CVV;
    protected String mesVencimiento;
    protected String anioVencimiento;
    
    
    //Constructor
    public Pago(String tipoTarjeta, String numTarjeta, String CVV, String mesVencimiento, String anioVencimiento) {
        this.tipoTarjeta = tipoTarjeta;
        this.numTarjeta = numTarjeta;
        this.CVV = CVV;
        this.mesVencimiento = mesVencimiento;
        this.anioVencimiento = anioVencimiento;
    }
    
    //Getters
    public String getTipoTarjeta() {
        return tipoTarjeta;
    }

    public String getNumTarjeta() {
        return numTarjeta;
    }

    public String getCVV() {
        return CVV;
    }

    public String getMesVencimiento() {
        return mesVencimiento;
    }

    public String getAnioVencimiento() {
        return anioVencimiento;
    }
    
    //Setters
    public void setTipoTarjeta(String tipoTarjeta) {
        this.tipoTarjeta = tipoTarjeta;
    }

    public void setNumTarjeta(String numTarjeta) {
        this.numTarjeta = numTarjeta;
    }

    public void setCVV(String CVV) {
        this.CVV = CVV;
    }

    public void setMesVencimiento(String mesVencimiento) {
        this.mesVencimiento = mesVencimiento;
    }

    public void setAnioVencimiento(String anioVencimiento) {
        this.anioVencimiento = anioVencimiento;
    }
    
    
}
