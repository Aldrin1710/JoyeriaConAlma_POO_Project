/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Collares extends Accesorios{
    
    protected String tipoAlambre;

    public Collares(String id, String nombreProducto, String descripcion, int cantidad, double costo, String tipoAlambre) {
        super(id, nombreProducto, descripcion, cantidad, costo);
        this.tipoAlambre = tipoAlambre;
    }

    public String getTipoAlambre() {
        return tipoAlambre;
    }

    public void setTipoAlambre(String tipoAlambre) {
        this.tipoAlambre = tipoAlambre;
    }
    
    
    //metodo abstracto
    @Override
    public double calcularCostoTotal() {
     return cantidad * costo;
    }

    @Override
    public String toString() {
        return super.toString() + "Collares{" + "tipoAlambre=" + tipoAlambre + '}';
    }
    
    
}
