/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Rosarios extends Accesorios{
    
    protected String detalles;

    public Rosarios( String id, String nombreProducto, String descripcion, int cantidad, double costo, String detalles) {
        super(id, nombreProducto, descripcion, cantidad, costo);
        this.detalles = detalles;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }
    
    
    
    //metodo abstracto
    @Override
    public double calcularCostoTotal() {
        return costo * cantidad;
    }
    
    
}
