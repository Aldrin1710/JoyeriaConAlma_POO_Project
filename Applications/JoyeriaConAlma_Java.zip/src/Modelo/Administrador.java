/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author aldri
 */
public class Administrador extends Persona{
    
    //Atributos
    protected String ID;
    protected String fechaIngreso;

    public Administrador(String nombre, String apellidoPaterno, String apellidoMaterno, String correo, String password, String ID, String fechaIngreso) {
        super(nombre, apellidoPaterno, apellidoMaterno, correo, password);
        this.ID = ID;
        this.fechaIngreso = fechaIngreso;
    }
    
    //Getters
    public String getID() {
        return ID;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }
    
    //Setters
    public void setID(String ID) {
        this.ID = ID;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    @Override
    public String toString() {
        return super.toString() + " ID=" + ID + ", fechaIngreso=" + fechaIngreso + '}';
    }
    
    
    
    
    
}
