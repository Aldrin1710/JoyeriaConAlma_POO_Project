/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;

/**
 *
 * @author aldri
 */
public abstract class Producto implements Serializable{
    //Atributos
    protected String id;
    protected String nombreProducto;
    protected String descripcion;
    
    //Constructor
    public Producto(String id, String nombreProducto, String descripcion) {
        this.id = id;
        this.nombreProducto = nombreProducto;
        this.descripcion = descripcion;
    }
    
    
    //Getters
    public String getId() {
        return id;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }
    
    //Setters
    public void setId(String id) {
        this.id = id;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    //Metodo abstracto: calcularCostoTotal();
    public abstract double calcularCostoTotal();
    
    
    //toString
    @Override
    public String toString() {
        return "Producto{" + "id=" + id + ", nombreProducto=" + nombreProducto + ", descripcion=" + descripcion + '}';
    }
    
    
}
