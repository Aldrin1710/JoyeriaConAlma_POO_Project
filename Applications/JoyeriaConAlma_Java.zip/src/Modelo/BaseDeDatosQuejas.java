package Modelo;

import java.util.ArrayList;
import java.util.List;

public class BaseDeDatosQuejas {
    private static final List<Queja> listaQuejas = new ArrayList<>();

    public static void agregarQueja(Queja queja) {
        listaQuejas.add(queja);
    }

    public static List<Queja> obtenerQuejas() {
        return listaQuejas;
    }
}
